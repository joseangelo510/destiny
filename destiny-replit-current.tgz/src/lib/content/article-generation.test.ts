import { describe, expect, it } from "vitest";
import {
  ANTHROPIC_REQUEST_TIMEOUT_MS,
  ARTICLE_MAX_TOKENS,
  ARTICLE_WEB_SEARCH_MAX_USES,
  DEFAULT_ARTICLE_PREFERENCES,
  DEFAULT_COPY_MODEL,
  sanitizeAnthropicError,
  buildAnthropicArticleRequest,
  buildArticleGenerationPrompt,
  renderInfographicSvg,
  resolveArticleGenerationCapability,
  validateGeneratedArticle,
  type GeneratedArticlePayload,
} from "./article-generation";

function validLongFormPayload(): GeneratedArticlePayload {
  const sections = [
    ["## SEO Content Strategy: Start With the Searcher", "### Turn intent into a useful outline"],
    ["## What the Best Pages Explain First", "### Answer the decision behind the query"],
    ["## A Practical Research Workflow", "### Verify every claim before drafting"],
    ["## Why Generic Advice Falls Flat", "### Add a point of view competitors cannot copy"],
    ["## Measure the Result That Matters", "### Connect rankings to qualified action"],
    ["## Your Next Publishing Step", "### Review the draft before it goes live"],
  ];
  const paragraphs = sections.flatMap(([h2, h3], sectionIndex) => {
    const words = Array.from({ length: 345 }, (_, wordIndex) => `detail${sectionIndex}x${wordIndex}`).join(" ");
    const citation = sectionIndex < 3 ? ` [Verified source ${sectionIndex + 1}](https://example.com/source-${sectionIndex + 1})` : "";
    return [h2, "", `So what should you do with section ${sectionIndex + 1}?`, "", `${words}${citation}`, "", h3, "", `Use this worked example for section ${sectionIndex + 1}.`];
  });
  return {
    title: "SEO Content Strategy: A Practical Growth Guide",
    metaDescriptions: [
      "Build an SEO content strategy with credible research, useful examples, and a clear publishing plan.",
      "Learn how an SEO content strategy connects search intent, original insight, and measurable business growth.",
    ],
    bodyMarkdown: ["# SEO Content Strategy: A Practical Growth Guide", "", ...paragraphs].join("\n"),
    bucketBrigades: sections.map((_, index) => ({ text: `So what should you do with section ${index + 1}?`, afterWord: 100 + index * 330 })),
    sources: [1, 2, 3].map((index) => ({
      id: `source-${index}`,
      title: `Verified source ${index}`,
      url: `https://example.com/source-${index}`,
    })),
    infographics: [],
  };
}

describe("Destiny article generation policy", () => {
  it("keeps Jose's approved controls and SEO-article defaults", () => {
    expect(DEFAULT_ARTICLE_PREFERENCES).toEqual({
      voice: "punchy_coach",
      format: "seo_article",
      readingEase: "simple_clear",
      specialInstructions: "",
      addInfographics: true,
    });
    expect(DEFAULT_COPY_MODEL).toBe("claude-opus-4-8");
  });

  it("builds a hidden prompt with the locked long-form, heading, brigade, source, and graphics rules", () => {
    const prompt = buildArticleGenerationPrompt({
      keyword: "seo content strategy",
      businessName: "Destiny",
      problemSolved: "Founders need a repeatable organic growth system.",
      idealCustomer: "Founder-led businesses",
      differentiation: "Fifteen years of practical SEO experience",
      internalPages: [{ title: "Destiny home", url: "https://example.com/", text: "SEO coaching for founders" }],
      preferences: { ...DEFAULT_ARTICLE_PREFERENCES, specialInstructions: "Mention the free strategy call once." },
    });

    expect(prompt).toContain("2,000–3,000 words");
    expect(prompt).toContain("6–9 H2 sections");
    expect(prompt).toContain("4–9 contextual bucket brigades");
    expect(prompt).toContain("first 150 words");
    expect(prompt).toContain("at least 40% of headings");
    expect(prompt).toContain("original infographic");
    expect(prompt).toContain("Mention the free strategy call once.");
    expect(prompt).toContain("Never fabricate");
    expect(prompt).not.toContain("write like Neil Patel");
  });

  it("configures Opus 4.8 with server-side web research instead of asking the model to invent sources", () => {
    const request = buildAnthropicArticleRequest("Research and write the article.", "claude-opus-4-8");
    expect(request.max_tokens).toBe(6000);
    expect(request.model).toBe("claude-opus-4-8");
    expect(request.tools).toEqual([{ type: "web_search_20260209", name: "web_search", max_uses: 4 }]);
    expect(request.messages[0]).toEqual({ role: "user", content: "Research and write the article." });
  });

  it("accepts a substantive SEO article and rejects short or stock-phrase drafts", () => {
    const valid = validLongFormPayload();
    expect(validateGeneratedArticle(valid, "seo content strategy", "seo_article")).toEqual([]);

    const invalid = {
      ...valid,
      bodyMarkdown: "# SEO Content Strategy\n\n## SEO Content Strategy Basics\n\nLet's dive in. This is short.",
      bucketBrigades: [{ text: "Let's dive in.", afterWord: 8 }],
    };
    expect(validateGeneratedArticle(invalid, "seo content strategy", "seo_article").map((issue) => issue.code)).toEqual(expect.arrayContaining([
      "word_count",
      "heading_structure",
      "heading_variety",
      "brigade_count",
      "source_coverage",
      "stock_phrase",
    ]));
  });

  it("renders an original, source-labeled SVG instead of reusing a third-party infographic", () => {
    const svg = renderInfographicSvg({
      id: "steps-1",
      template: "steps",
      title: "A Better Content Workflow",
      insight: "Research before writing",
      items: ["Find intent", "Verify sources", "Draft", "Review"],
      sourceLabel: "Source: Destiny article research",
      altText: "Four-step content workflow from search intent through review",
    });
    expect(svg).toContain("<svg");
    expect(svg).toContain("A Better Content Workflow");
    expect(svg).toContain("Source: Destiny article research");
    expect(svg).not.toContain("<image");
  });
});

describe("article generation request budget and error handling", () => {
  it("keeps the generation budget bounded for a 2,000–3,000-word article", () => {
    const request = buildAnthropicArticleRequest("Write the article.");
    expect(request.model).toBe(DEFAULT_COPY_MODEL);
    expect(request.max_tokens).toBe(ARTICLE_MAX_TOKENS);
    expect(ARTICLE_MAX_TOKENS).toBe(6000);
    expect(request.tools).toEqual([{ type: "web_search_20260209", name: "web_search", max_uses: ARTICLE_WEB_SEARCH_MAX_USES }]);
    expect(ARTICLE_WEB_SEARCH_MAX_USES).toBe(4);
  });

  it("aborts server-side before Replit's 300-second function ceiling", () => {
    expect(ANTHROPIC_REQUEST_TIMEOUT_MS).toBeLessThan(300_000);
    expect(ANTHROPIC_REQUEST_TIMEOUT_MS).toBeGreaterThanOrEqual(240_000);
  });

  it("builds a sanitized actionable error with provider status and code", () => {
    const sanitized = sanitizeAnthropicError(429, { error: { type: "rate_limit_error", message: "Rate limited. Retry later." } });
    expect(sanitized.error).toContain("HTTP 429");
    expect(sanitized.error).toContain("rate_limit_error");
    expect(sanitized.error).toContain("Rate limited. Retry later.");
    expect(sanitized.code).toBe("rate_limit_error");
    expect(sanitized.httpStatus).toBe(429);
  });

  it("redacts key-like strings and maps provider 5xx to a 502 without leaking internals", () => {
    const sanitized = sanitizeAnthropicError(529, { error: { type: "overloaded_error", message: "Bad key sk-ant-api03-SECRETSECRET provided" } });
    expect(sanitized.error).not.toContain("SECRETSECRET");
    expect(sanitized.error).toContain("[redacted]");
    expect(sanitized.httpStatus).toBe(502);
  });

  it("survives an unparseable provider error body", () => {
    const sanitized = sanitizeAnthropicError(500, "not json");
    expect(sanitized.error).toContain("HTTP 500");
    expect(sanitized.code).toBe("unknown_error");
    expect(sanitized.httpStatus).toBe(502);
  });
});

describe("resolveArticleGenerationCapability", () => {
  it("reports unavailable with an honest label when the Anthropic key is absent", () => {
    for (const anthropicApiKey of [undefined, null, "", "   "]) {
      const capability = resolveArticleGenerationCapability({ anthropicApiKey, copyModel: "claude-opus-4-8" });
      expect(capability.available).toBe(false);
      expect(capability.modelLabel).toBe("Article model unavailable");
    }
  });

  it("reports the configured copy model when the key is present", () => {
    const capability = resolveArticleGenerationCapability({ anthropicApiKey: "sk-ant-test", copyModel: "claude-opus-4-9" });
    expect(capability).toEqual({ available: true, modelLabel: "claude-opus-4-9" });
  });

  it("falls back to the default copy model when no model override is set", () => {
    for (const copyModel of [undefined, null, "", "  "]) {
      const capability = resolveArticleGenerationCapability({ anthropicApiKey: "sk-ant-test", copyModel });
      expect(capability).toEqual({ available: true, modelLabel: DEFAULT_COPY_MODEL });
    }
  });
});
