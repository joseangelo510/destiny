import { sendMagicLink } from "./actions";

type LoginPageProps = {
  searchParams: Promise<{ email?: string; error?: string; next?: string; sent?: string }>;
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const params = await searchParams;
  return (
    <main className="login-shell">
      <section className="login-card">
        <div className="brand"><span className="brand-mark">D</span><span>Destiny</span></div>
        {params.sent === "1" ? (
          <>
            <div className="eyebrow">Check your inbox</div>
            <h1>Your path is waiting.</h1>
            <p>We sent a secure sign-in link to <strong>{params.email}</strong>. Open it in this browser to continue.</p>
            <a className="secondary-button login-link" href="/login">Use another email</a>
          </>
        ) : (
          <>
            <div className="eyebrow">Welcome to Destiny</div>
            <h1>Make SEO a habit that compounds.</h1>
            <p>Enter your email. No password required—we’ll send you a secure sign-in link.</p>
            <form action={sendMagicLink}>
              <input name="next" type="hidden" value={params.next ?? "/"} />
              <label>Email address<input autoComplete="email" name="email" required type="email" /></label>
              {params.error && <div className="error-banner">{params.error}</div>}
              <button className="primary-button" type="submit">Email me a sign-in link</button>
            </form>
          </>
        )}
      </section>
    </main>
  );
}

