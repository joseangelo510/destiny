import { RankTrackerWorkspace, type RankTrackerKeyword } from "@/components/rank-tracker-workspace";
import { WorkspaceEmpty } from "@/components/workspace-empty";
import { WorkspaceShell } from "@/components/workspace-shell";
import { getWorkspaceContext } from "@/lib/workspace-context";

export const dynamic = "force-dynamic";

export default async function RankTrackerPage() {
  const context = await getWorkspaceContext();
  if (!context.website) return <WorkspaceShell active="/rank-tracker" eyebrow="Destiny workspace" title="Rank tracker" description="Track the Google positions connected to your approved strategy."><WorkspaceEmpty title="Complete onboarding first" description="Add your website so Destiny knows which domain to measure." /></WorkspaceShell>;

  const [{ data: lists }, { data: tracked }, { data: observations }] = await Promise.all([
    context.supabase.from("rank_tracker_lists").select("id,name").eq("website_id", context.website.id).order("name"),
    context.supabase.from("tracked_keywords").select("id,keyword,list_id,status,source,created_at,last_checked_at").eq("website_id", context.website.id).neq("status", "paused").order("created_at"),
    context.supabase.from("rank_observations").select("tracked_keyword_id,observed_at,found,position,result_url").eq("website_id", context.website.id).order("observed_at", { ascending: false }).limit(2000),
  ]);

  const byKeyword = (observations ?? []).reduce<Record<string, typeof observations>>((grouped, observation) => {
    const values = grouped[observation.tracked_keyword_id] ?? [];
    if (values.length < 8) grouped[observation.tracked_keyword_id] = [...values, observation];
    return grouped;
  }, {});
  const rows: RankTrackerKeyword[] = (tracked ?? []).map((row) => {
    const history = byKeyword[row.id] ?? [];
    const latest = history[0];
    const previous = history[1];
    return {
      id: row.id,
      keyword: row.keyword,
      listId: row.list_id,
      status: row.status,
      source: row.source,
      createdAt: row.created_at,
      lastCheckedAt: row.last_checked_at,
      currentPosition: latest?.found ? latest.position : null,
      previousPosition: previous?.found ? previous.position : null,
      previousFound: previous ? previous.found : null,
      found: latest ? latest.found : null,
      resultUrl: latest?.result_url ?? null,
      checkedAt: latest?.observed_at ?? null,
      history: history.map((observation) => ({ observedAt: observation.observed_at, position: observation.position, found: observation.found })),
    };
  });

  return <WorkspaceShell active="/rank-tracker" eyebrow={context.website.normalized_domain} title="Rank tracker" description="Follow the keywords you approved, organize them into lists, and compare evidence-backed Google positions on a consistent weekly cadence.">
    <RankTrackerWorkspace initialKeywords={rows} initialLists={lists ?? []} websiteId={context.website.id} />
  </WorkspaceShell>;
}
