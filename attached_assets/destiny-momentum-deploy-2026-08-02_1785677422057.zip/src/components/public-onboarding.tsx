"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { AuditMomentumProcessing } from "./audit-momentum-processing";
import { CompassCompanion } from "./compass-companion";
import { stepOneValidation, stepTwoValidation } from "../lib/onboarding/validation";
import { validateCompetitorEntries } from "../lib/onboarding/competitors";
import {
  DEFAULT_CELEBRATION_PREFERENCES,
  playDestinySound,
  readCelebrationPreferences,
  saveCelebrationPreferences,
  type CelebrationPreferences,
} from "../lib/product/celebrations";
import {
  ONBOARDING_MOMENTUM_STAGES,
  onboardingMomentumJourney,
} from "../lib/product/momentum-journey";

type VoiceField = "productsServices" | "problem" | "customer" | "audienceGoals" | "competitors" | "standout";

type SpeechRecognitionEventLike = {
  results: { 0: { 0: { transcript: string } } };
};

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
};

type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

const emptyForm = {
  website: "",
  businessName: "",
  productsServices: "",
  problem: "",
  customer: "",
  audienceGoals: "",
  localMarket: "",
  country: "United States",
  competitors: "",
  standout: "",
  firstName: "",
  lastName: "",
  email: "",
};

const countries = [
  "United States", "Canada", "United Kingdom", "Australia", "New Zealand", "Ireland",
  "France", "Germany", "Spain", "Italy", "Netherlands", "Belgium", "Sweden", "Norway",
  "Denmark", "Finland", "Singapore", "India", "Japan", "Brazil", "Mexico",
];

export function PublicOnboarding() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState(emptyForm);
  const [listening, setListening] = useState<VoiceField | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [auditStatus, setAuditStatus] = useState<"idle" | "running" | "failed">("idle");
  const [auditProgress, setAuditProgress] = useState(0);
  const [celebration, setCelebration] = useState("");
  const [celebrationPreferences, setCelebrationPreferences] = useState<CelebrationPreferences>(DEFAULT_CELEBRATION_PREFERENCES);
  const [celebrationsReady, setCelebrationsReady] = useState(false);

  const updateField = (field: keyof typeof form, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const stepOne = useMemo(() => stepOneValidation(form), [form]);
  const stepTwo = useMemo(() => stepTwoValidation(form), [form]);
  const competitorValidation = useMemo(() => validateCompetitorEntries(form.competitors), [form.competitors]);
  const onboardingJourney = useMemo(() => onboardingMomentumJourney(step), [step]);

  const stepReady = useMemo(() => {
    if (step === 1) return stepOne.ready;
    if (step === 2) return stepTwo.ready;
    if (step === 3) return form.standout.trim().length > 0 && competitorValidation.ready;
    return form.firstName.trim().length > 0 && form.lastName.trim().length > 0 && /^\S+@\S+\.\S+$/.test(form.email.trim());
  }, [competitorValidation.ready, form, step, stepOne.ready, stepTwo.ready]);

  useEffect(() => {
    const saved = readCelebrationPreferences();
    document.documentElement.dataset.reducedCelebrations = String(saved.reduced);
    const hydrationTimer = window.setTimeout(() => {
      setCelebrationPreferences(saved);
      setCelebrationsReady(true);
    }, 0);
    return () => window.clearTimeout(hydrationTimer);
  }, []);

  useEffect(() => {
    if (!celebration) return;
    const timer = window.setTimeout(() => setCelebration(""), 2100);
    return () => window.clearTimeout(timer);
  }, [celebration]);

  const dictate = (field: VoiceField) => {
    const Constructor = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!Constructor) {
      setError("Voice input is not supported in this browser. Chrome is recommended.");
      return;
    }

    setError("");
    setListening(field);
    const recognition = new Constructor();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setForm((current) => ({ ...current, [field]: `${current[field]} ${transcript}`.trim() }));
    };
    recognition.onerror = () => setError("Destiny could not hear you. Allow microphone access in Chrome and try again.");
    recognition.onend = () => setListening(null);
    recognition.start();
  };

  const nextStep = () => {
    if (!stepReady) return;
    setError("");
    if (step === 1 && stepOne.normalizedWebsite) {
      setForm((current) => ({ ...current, website: stepOne.normalizedWebsite ?? current.website }));
    }
    const completedStage = ONBOARDING_MOMENTUM_STAGES[step - 1];
    setStep((current) => Math.min(4, current + 1));
    setCelebration(completedStage.celebration);
    void playDestinySound("task_complete");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (step !== 4 || !stepReady) return;
    setLoading(true);
    setError("");
    try {
      const sessionResponse = await fetch("/api/auth/anonymous", { method: "POST" });
      const sessionPayload = await sessionResponse.json() as { error?: string };
      if (!sessionResponse.ok) throw new Error(sessionPayload.error || "Destiny could not start your workspace.");

      const onboardingResponse = await fetch("/api/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const onboardingPayload = await onboardingResponse.json() as { error?: string; websiteId?: string };
      if (!onboardingResponse.ok || !onboardingPayload.websiteId) {
        throw new Error(onboardingPayload.error || "Destiny could not save your business profile.");
      }

      setAuditStatus("running");
      setAuditProgress(0);
      const auditResponse = await fetch("/api/audits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          website: form.website,
          websiteId: onboardingPayload.websiteId,
          locationName: form.country,
        }),
      });
      const auditPayload = await auditResponse.json() as { auditId?: string; error?: string; progress?: number };
      if (!auditResponse.ok || !auditPayload.auditId) {
        throw new Error(auditPayload.error || "Destiny could not run your audit.");
      }
      setAuditProgress(typeof auditPayload.progress === "number" ? auditPayload.progress : 10);
      window.location.assign(`/audits/${encodeURIComponent(auditPayload.auditId)}`);
    } catch (cause) {
      setAuditStatus("failed");
      setError(cause instanceof Error ? cause.message : "Destiny could not create your plan.");
    } finally {
      setLoading(false);
    }
  };

  const toggleSound = () => {
    const next = { ...celebrationPreferences, muted: !celebrationPreferences.muted };
    setCelebrationPreferences(next);
    saveCelebrationPreferences(next);
  };

  if (auditStatus !== "idle") {
    return <AuditMomentumProcessing failureMessage={error} initialProgress={auditProgress} initialStatus={auditStatus} onRetry={() => { setAuditStatus("idle"); setAuditProgress(0); setStep(4); }} website={form.website} />;
  }

  return (
    <main className="guided-onboarding-shell">
      <header className="guided-onboarding-header">
        <Link className="brand" href="/" aria-label="Return to Destiny home"><span className="brand-mark">D</span><span>Destiny</span></Link>
        <span className="live-connection"><i />Live SEO data connected</span>
        <div className="guided-header-actions"><button aria-label={celebrationPreferences.muted ? "Turn Destiny sounds on" : "Mute Destiny sounds"} className="onboarding-sound-toggle" disabled={!celebrationsReady} onClick={toggleSound} type="button">{celebrationPreferences.muted ? "Sound off" : "♪ Sound on"}</button><button aria-label="Open notifications" className="guided-notification" title="Notifications become available after your audit starts" type="button">◇</button></div>
      </header>

      <div className="guided-onboarding-layout">
        <aside className="guided-onboarding-intro">
          <p className="eyebrow">Your guided SEO starting line</p>
          <h1>Build the momentum to be found.</h1>
          <p>You bring the business knowledge. Destiny turns it into the research, priorities, and weekly coaching an SEO agency would normally prepare.</p>
          <div className="onboarding-momentum-summary"><CompassCompanion compact completed={onboardingJourney.completedCount} total={ONBOARDING_MOMENTUM_STAGES.length} /><div><span>Your path</span><strong>{onboardingJourney.completedCount} of {ONBOARDING_MOMENTUM_STAGES.length} building blocks complete</strong><div aria-hidden="true" className="onboarding-momentum-track"><span style={{ width: `${onboardingJourney.percent}%` }} /></div></div></div>
          <ol aria-label="Onboarding journey" className="guided-stage-list">
            {onboardingJourney.stages.map((stage, index) => {
              const number = index + 1;
              return <li aria-current={stage.state === "active" ? "step" : undefined} className={stage.state} key={stage.id}><span>{stage.state === "complete" ? "✓" : number}</span><div><strong>{stage.title}</strong><small>{stage.description}</small>{stage.state === "active" && <em>Building now</em>}</div></li>;
            })}
          </ol>
          <div className="guided-evidence"><strong>Small steps. Real evidence. No SEO team required.</strong><p>Each answer makes the strategy more useful. After this path, Destiny handles the live research and shows you exactly what it is doing.</p></div>
        </aside>

        <form className="guided-onboarding-card" onSubmit={submit}>
          <span className="guided-step">Step {step} of 4</span>

          {step === 1 && <>
            <h2>Tell us about your business</h2>
            <p className="lede">Start with a public website, what you provide, and the customer problem your business solves.</p>
            <label>Business name<input autoComplete="organization" onChange={(event) => updateField("businessName", event.target.value)} placeholder="Nike" required value={form.businessName} /></label>
            <label>Website URL<input aria-describedby="website-help" autoComplete="url" inputMode="url" onChange={(event) => updateField("website", event.target.value)} placeholder="yourwebsite.com or https://yourwebsite.com" required type="text" value={form.website} /><small id="website-help">Any public website you are authorized to analyze</small></label>
            <VoiceTextarea field="productsServices" label="Tell us about your business and the products or services you provide" listening={listening} onChange={(value) => updateField("productsServices", value)} onDictate={dictate} placeholder="Describe your main products or services in clear, everyday language." value={form.productsServices} />
            <VoiceTextarea field="problem" label="What problem are you solving with your products or services?" listening={listening} onChange={(value) => updateField("problem", value)} onDictate={dictate} placeholder="Describe the costly, frustrating, or important problem customers need you to solve." value={form.problem} />
          </>}

          {step === 2 && <>
            <h2>Who is your ideal customer?</h2>
            <p className="lede">Local context shapes the strategy; the country selects the supported keyword database.</p>
            <VoiceTextarea field="customer" label="Ideal customer" listening={listening} onChange={(value) => updateField("customer", value)} onDictate={dictate} placeholder="Describe who they are, what they need, and what makes them ready to buy." value={form.customer} />
            <VoiceTextarea field="audienceGoals" label="What challenges and goals do you want to help your audience with?" listening={listening} onChange={(value) => updateField("audienceGoals", value)} onDictate={dictate} placeholder="Share what they are struggling with today and the outcome they want to achieve." value={form.audienceGoals} />
            <label>Local market <em>Optional</em><input onChange={(event) => updateField("localMarket", event.target.value)} placeholder="San Francisco, California" value={form.localMarket} /><small>Used as strategy context; not sent as a DataForSEO country.</small></label>
            <label>Search database country<select onChange={(event) => updateField("country", event.target.value)} value={form.country}>{countries.map((country) => <option key={country}>{country}</option>)}</select><small>DataForSEO Labs uses a supported country-level search database.</small></label>
          </>}

          {step === 3 && <>
            <h2>Who are your competitors?</h2>
            <p className="lede">Add at least two real competitors. Website URLs produce the strongest gap analysis; Destiny can still research names.</p>
            <VoiceTextarea field="competitors" label="Known competitors" listening={listening} onChange={(value) => updateField("competitors", value)} onDictate={dictate} placeholder={"One competitor per line\nIvyWise — ivywise.com\nCollegewise — collegewise.com"} value={form.competitors} />
            {form.competitors.trim() && !competitorValidation.ready && <div aria-live="polite" className="field-error" role="alert">{competitorValidation.error}</div>}
            <VoiceTextarea field="standout" label="What makes you stand out from competitors?" listening={listening} onChange={(value) => updateField("standout", value)} onDictate={dictate} placeholder="Share your experience, point of view, proof, and what customers value about working with you." value={form.standout} />
          </>}

          {step === 4 && <>
            <h2>Ready to build your search baseline?</h2>
            <p className="lede">Tell us where to send your updates, review the details, then start a real analysis.</p>
            <div className="form-grid two-column">
              <label>First name<input autoComplete="given-name" onChange={(event) => updateField("firstName", event.target.value)} placeholder="Maya" required value={form.firstName} /></label>
              <label>Last name<input autoComplete="family-name" onChange={(event) => updateField("lastName", event.target.value)} placeholder="Torres" required value={form.lastName} /></label>
            </div>
            <label>Contact email<input autoComplete="email" onChange={(event) => updateField("email", event.target.value)} placeholder="maya@yourbusiness.com" required type="email" value={form.email} /><small>We’ll use this for your welcome and audit-ready updates. It is not an email verification gate.</small></label>
            <div className="guided-review-grid">
              <div><span>Business name</span><strong>{form.businessName}</strong></div>
              <div><span>Website</span><strong>{form.website}</strong></div>
              <div><span>Search database</span><strong>{form.country}</strong></div>
              <div><span>Products and services</span><p>{form.productsServices}</p></div>
              <div><span>Problem being solved</span><p>{form.problem}</p></div>
              <div><span>Ideal customer</span><p>{form.customer}</p></div>
              <div><span>Audience challenges and goals</span><p>{form.audienceGoals}</p></div>
              <div><span>Local market</span><strong>{form.localMarket || "Not specified"}</strong></div>
              <div><span>Known competitors</span><p>{form.competitors || "Let Destiny discover them from organic search overlap"}</p></div>
              <div className="wide"><span>What makes you stand out</span><p>{form.standout}</p></div>
            </div>
            <div className="guided-next"><strong>What happens next</strong><p>Destiny checks ranking keywords, keyword opportunities, measured organic competitors, crawl pages, and mobile performance. The notification center saves progress and completion updates.</p></div>
          </>}

          {error && <div className="error-banner">{error}</div>}
          <div className="guided-actions">
            {step === 1 ? <Link className="secondary-button" href="/">Back to home</Link> : <button className="secondary-button" onClick={() => { setError(""); setStep((current) => current - 1); }} type="button">Back</button>}
            {step < 4 ? <button className="primary-button" disabled={!stepReady} onClick={nextStep} type="button">Continue</button> : <button className="primary-button" disabled={!stepReady || loading} type="submit">{loading ? "Starting analysis…" : "Run live analysis"}</button>}
          </div>
        </form>
      </div>
      {celebration && <div aria-live="polite" className="destiny-celebration"><span>⌁</span><strong>{celebration}</strong></div>}
    </main>
  );
}

function VoiceTextarea({ field, label, listening, onChange, onDictate, optional = false, placeholder, value }: {
  field: VoiceField;
  label: string;
  listening: VoiceField | null;
  onChange: (value: string) => void;
  onDictate: (field: VoiceField) => void;
  optional?: boolean;
  placeholder: string;
  value: string;
}) {
  return <label><span className="label-row"><span>{label} {optional && <em>Optional</em>}</span><button className={listening === field ? "voice-button listening" : "voice-button"} onClick={() => onDictate(field)} type="button">{listening === field ? "Listening…" : "◉ Talk instead"}</button></span><textarea onChange={(event) => onChange(event.target.value)} placeholder={placeholder} required={!optional} rows={4} value={value} /></label>;
}
