import {
  createBusinessSearchBrief,
  themeSeeds,
  type BusinessSearchBrief,
  type BusinessSearchBriefConfig,
  type BusinessSearchContext,
} from "./business-search-brief.ts";
import { rankKeywordOpportunities, selectDiversifiedKeywordOpportunities } from "./keyword-opportunity.ts";
import {
  extractSiteVocabulary,
  parseContentPage,
  parseDistributionSerp,
  parseLlmVisibility,
  parsePublisherSerp,
  selectImportantPageLinks,
  type DistributionOpportunity,
  type LlmVisibility,
  type PublisherOpportunity,
  type SitePageEvidence,
  type SiteVocabularyTerm,
} from "./intelligence.ts";

export type AuditSource = "demo" | "dataforseo";

export type SeoAuditResult = {
  source: AuditSource;
  sourceLabel: string;
  domain: string;
  fetchedAt: string;
  metrics: {
    criticalIssues: number;
    warnings: number;
    rankingKeywords: number;
    newKeywords: number;
    lostKeywords: number;
    estimatedOrganicTraffic: number;
    contentGaps: number;
    reviewCount: number;
    onPageScore: number | null;
  };
  historicalPerformance?: Array<{
    year: number;
    month: number;
    organicTraffic: number;
    rankingKeywords: number;
    top3Keywords: number;
    top10Keywords: number;
    newKeywords: number;
    lostKeywords: number;
  }>;
  issues: Array<{ code: string; label: string; severity: "critical" | "warning" }>;
  competitors: Array<{ domain: string; sharedKeywords: number }>;
  keywords: Array<{
    keyword: string;
    rank: number;
    searchVolume: number;
    url: string;
    intent: string;
    difficulty: number;
    cpc: number;
    opportunity: "existing_rank" | "competitor_gap" | "site_idea";
    normalizedKeyword?: string;
    matchedTerms?: string[];
    competitorRankers?: number;
    directCompetitorRankers?: number;
    providerIntent?: "transactional" | "commercial" | "navigational" | "informational";
    searchIntent?: "conversion" | "consideration" | "awareness";
    businessFit?: number;
    revenueFit?: number;
    relevanceTier?: "core" | "adjacent";
    priorityTier?: 1 | 2 | 3 | 4;
    priorityScore?: number;
    priorityReason?: string;
    themeId?: string;
    themeLabel?: string;
    themeRole?: "conversion" | "consideration" | "awareness" | "technical_authority";
    verdict?: "accept" | "review" | "reject";
    ruleId?: string;
    reason?: string;
    essential?: boolean;
  }>;
  pages?: SitePageEvidence[];
  siteVocabulary?: SiteVocabularyTerm[];
  distributionOpportunities?: DistributionOpportunity[];
  publisherOpportunities?: PublisherOpportunity[];
  llmVisibility?: LlmVisibility;
  businessSearchBrief?: BusinessSearchBrief;
  notices: string[];
};

type JsonRecord = Record<string, unknown>;

const CRITICAL_CHECKS = new Set([
  "canonical_to_broken", "has_redirect", "is_4xx_code", "is_5xx_code",
  "is_broken", "no_content", "no_description", "no_h1_tag", "no_title",
]);

const CHECK_LABELS: Record<string, string> = {
  canonical_to_broken: "Canonical URL points to a broken page",
  canonical_to_redirect: "Canonical URL points to a redirect",
  deprecated_html_tags: "Page uses deprecated HTML tags",
  duplicate_meta_tags: "Page contains duplicate meta tags",
  duplicate_title_tag: "Page contains more than one title tag",
  has_meta_refresh_redirect: "Page uses a meta refresh redirect",
  has_micromarkup_errors: "Structured data contains errors",
  has_render_blocking_resources: "Page has render-blocking resources",
  has_redirect: "Page redirects before loading",
  high_loading_time: "Page takes more than three seconds to load",
  high_waiting_time: "Server response time is too slow",
  irrelevant_description: "Meta description does not match the page content",
  irrelevant_title: "Page title does not match the page content",
  is_4xx_code: "Page returns a 4xx response",
  is_5xx_code: "Page returns a 5xx response",
  is_broken: "Page is broken",
  is_http: "Page is not using HTTPS",
  large_page_size: "Page HTML is larger than one megabyte",
  low_character_count: "Page has too little readable text",
  low_content_rate: "Page has a low text-to-HTML ratio",
  low_readability_rate: "Page content is difficult to read",
  no_content: "Page has no readable content",
  no_content_encoding: "Page content is not compressed",
  no_description: "Meta description is missing",
  no_doctype: "HTML doctype is missing",
  no_h1_tag: "H1 heading is missing",
  no_image_alt: "Images are missing alt text",
  no_image_title: "Images are missing title attributes",
  no_title: "Page title is missing",
  small_page_size: "Page contains very little HTML content",
  title_too_long: "Page title is too long",
  title_too_short: "Page title is too short",
};

function record(value: unknown): JsonRecord {
  return value && typeof value === "object" && !Array.isArray(value) ? value as JsonRecord : {};
}
function array(value: unknown): unknown[] { return Array.isArray(value) ? value : []; }
function number(value: unknown) { return typeof value === "number" && Number.isFinite(value) ? value : 0; }
function string(value: unknown) { return typeof value === "string" ? value : ""; }

export function normalizeWebsite(value: string) {
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > 2048) throw new Error("Enter a valid public website.");
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  const url = new URL(withProtocol);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error("Website must use http or https.");
  const domain = url.hostname.toLowerCase().replace(/^www\./, "");
  const isIpAddress = /^\d{1,3}(?:\.\d{1,3}){3}$/.test(domain) || domain.includes(":");
  const isLocalName = domain === "localhost" || domain.endsWith(".localhost") || domain.endsWith(".local") || domain.endsWith(".internal");
  if (!domain || !domain.includes(".") || isIpAddress || isLocalName) throw new Error("Enter a valid public website.");
  url.username = "";
  url.password = "";
  url.hash = "";
  return { url: url.toString(), domain };
}

function stableNumber(value: string) {
  return [...value].reduce((total, character) => ((total * 31) + character.charCodeAt(0)) >>> 0, 2166136261);
}

type BusinessContext = BusinessSearchContext;

const realEstateTopics = [
  "san francisco homes for sale", "best san francisco neighborhoods for families", "first-time home buyer san francisco", "how to buy a home in san francisco",
  "san francisco home selling guide", "moving to san francisco with a family", "noe valley homes for families", "bernal heights homes for sale",
  "inner sunset homes for sale", "glen park homes for families", "san francisco school district home search", "how much house can i afford in san francisco",
  "san francisco home inspection checklist", "make a competitive home offer san francisco", "best time to sell a home in san francisco", "prepare a san francisco home for sale",
  "san francisco real estate market update", "closing costs for san francisco home buyers", "sell and buy a home at the same time", "relocating to san francisco neighborhoods",
  "family-friendly parks near san francisco homes", "walkable san francisco neighborhoods", "questions to ask a san francisco realtor", "choose a san francisco real estate agent",
];

const professionalTopics = [
  "services near me", "best local professional", "local service pricing guide", "how to choose a local provider",
  "questions to ask before hiring", "local provider reviews", "service comparison guide", "what to expect from a consultation",
  "common service mistakes to avoid", "local customer success story", "professional service checklist", "service options explained",
  "how long professional services take", "prepare for your first appointment", "local industry trends", "service costs and value",
  "when to hire a professional", "do it yourself versus hiring an expert", "local service frequently asked questions", "best solutions for growing businesses",
  "expert advice for first-time customers", "how to evaluate service quality", "local professional case study", "complete local services guide",
];

function demoKeywords(context: BusinessContext | undefined, domain: string, url: string, seed: number): SeoAuditResult["keywords"] {
  const description = `${context?.productsServices ?? ""} ${context?.problemSolved ?? ""} ${context?.idealCustomer ?? ""} ${context?.audienceChallengesGoals ?? ""}`.toLowerCase();
  const isRealEstate = /real estate|realtor|buy and sell homes|home buyer|home selling|property/.test(description);
  const topics = isRealEstate ? realEstateTopics : professionalTopics.map((topic, index) => index === 0 ? `${domain} services` : topic);
  return topics.map((keyword, index) => ({
    keyword,
    rank: index % 3 === 0 ? 11 + ((seed + index) % 35) : 0,
    searchVolume: 40 + ((seed + (index * 137)) % 950),
    url: index % 3 === 0 ? url : "",
    intent: /how|guide|questions|checklist|mistakes|update|versus|explained|expect|trends/.test(keyword) ? "informational" : "commercial",
    difficulty: 18 + ((seed + (index * 17)) % 55),
    cpc: 0.75 + (((seed + (index * 29)) % 650) / 100),
    opportunity: index % 3 === 0 ? "existing_rank" : index % 3 === 1 ? "competitor_gap" : "site_idea",
  }));
}

export function runDemoAudit(websiteValue: string, businessContext?: BusinessContext): SeoAuditResult {
  const website = normalizeWebsite(websiteValue);
  const seed = stableNumber(website.domain);
  const criticalIssues = 1 + (seed % 5);
  const now = new Date();
  const historicalPerformance = [2, 1, 0].map((monthsAgo, index) => {
    const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - monthsAgo, 1));
    return {
      year: date.getUTCFullYear(),
      month: date.getUTCMonth() + 1,
      organicTraffic: 120 + (seed % 150) + index * 35,
      rankingKeywords: 12 + (seed % 18) + index * 4,
      top3Keywords: 1 + index,
      top10Keywords: 4 + index * 2,
      newKeywords: 2 + index,
      lostKeywords: index === 0 ? 2 : 1,
    };
  });
  const issues: SeoAuditResult["issues"] = [
    { code: "missing_title", label: "Missing or weak page titles", severity: "critical" },
    { code: "broken_links", label: "Broken internal links", severity: "critical" },
    { code: "thin_content", label: "Pages with thin content", severity: "warning" },
  ];
  return {
    source: "demo",
    sourceLabel: "Demo audit data",
    domain: website.domain,
    fetchedAt: new Date().toISOString(),
    metrics: {
      criticalIssues,
      warnings: 4 + (seed % 8),
      rankingKeywords: 4 + (seed % 38),
      newKeywords: seed % 6,
      lostKeywords: seed % 3,
      estimatedOrganicTraffic: 40 + (seed % 900),
      contentGaps: 5 + (seed % 21),
      reviewCount: seed % 19,
      onPageScore: 62 + (seed % 28),
    },
    historicalPerformance,
    issues: issues.slice(0, Math.min(3, criticalIssues + 1)),
    competitors: [
      { domain: "local-search-competitor.example", sharedKeywords: 12 + (seed % 30) },
      { domain: "neighborhood-expert.example", sharedKeywords: 8 + (seed % 18) },
    ],
    keywords: demoKeywords(businessContext, website.domain, website.url, seed),
    notices: [
      "This is deterministic demonstration data, not a live SEO measurement.",
      "Add the DataForSEO API password to Supabase secrets to enable paid live checks.",
    ],
  };
}

function firstResult(payload: unknown) {
  const root = record(payload);
  const task = record(array(root.tasks)[0]);
  if (number(root.status_code) !== 20000 || number(task.status_code) !== 20000) {
    throw new Error(`DataForSEO rejected the audit: ${string(task.status_message) || string(root.status_message) || "Unknown API error"}`);
  }
  return record(array(task.result)[0]);
}

export function parseHistoricalRankOverview(payload: unknown) {
  const result = firstResult(payload);
  return array(result.items).map(record).map((item) => {
    const organic = record(record(item.metrics).organic);
    return {
      year: number(item.year),
      month: number(item.month),
      organicTraffic: number(organic.etv),
      rankingKeywords: number(organic.count),
      top3Keywords: number(organic.pos_1) + number(organic.pos_2_3),
      top10Keywords: number(organic.pos_1) + number(organic.pos_2_3) + number(organic.pos_4_10),
      newKeywords: number(organic.is_new),
      lostKeywords: number(organic.is_lost),
    };
  }).filter((point) => point.year > 2000 && point.month >= 1 && point.month <= 12)
    .sort((left, right) => (left.year * 12 + left.month) - (right.year * 12 + right.month));
}

function authorization(login: string, password: string) {
  const bytes = new TextEncoder().encode(`${login}:${password}`);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return `Basic ${btoa(binary)}`;
}

export async function dataForSeoPost(path: string, body: JsonRecord[], login: string, password: string, timeout = 60_000) {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const request = (async () => {
    const response = await fetch(`https://api.dataforseo.com${path}`, {
      method: "POST",
      headers: { Authorization: authorization(login, password), "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`DataForSEO returned HTTP ${response.status}.`);
    return response.json() as Promise<unknown>;
  })();
  const deadline = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new Error(`DataForSEO request timed out after ${timeout}ms.`));
    }, timeout);
  });
  try {
    return await Promise.race([request, deadline]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

type StrategyKeyword = SeoAuditResult["keywords"][number];

function parseRankedKeywords(result: JsonRecord): StrategyKeyword[] {
  return array(result.items).slice(0, 100).map((item) => {
    const row = record(item);
    const keywordData = record(row.keyword_data);
    const keywordInfo = record(keywordData.keyword_info);
    const keywordProperties = record(keywordData.keyword_properties);
    const serpItem = record(record(row.ranked_serp_element).serp_item);
    return {
      keyword: string(keywordData.keyword),
      rank: number(serpItem.rank_group) || number(serpItem.rank_absolute),
      searchVolume: number(keywordInfo.search_volume),
      url: string(serpItem.url),
      intent: string(keywordProperties.main_intent),
      difficulty: number(keywordProperties.keyword_difficulty) || number(keywordData.keyword_difficulty),
      cpc: number(keywordInfo.cpc),
      opportunity: "existing_rank" as const,
    };
  }).filter((keyword) => keyword.keyword);
}

function parseKeywordIdeas(result: JsonRecord): StrategyKeyword[] {
  return array(result.items).slice(0, 150).map((item) => {
    const row = record(item);
    const keywordInfo = record(row.keyword_info);
    return {
      keyword: string(row.keyword),
      rank: 0,
      searchVolume: number(keywordInfo.search_volume),
      url: "",
      intent: string(record(row.search_intent_info).main_intent),
      difficulty: number(record(row.keyword_properties).keyword_difficulty),
      cpc: number(keywordInfo.cpc),
      opportunity: "site_idea" as const,
    };
  }).filter((keyword) => keyword.keyword);
}

function parseGapKeywords(result: JsonRecord): StrategyKeyword[] {
  return array(result.items).slice(0, 150).map((item) => {
    const keywordData = record(record(item).keyword_data);
    const keywordInfo = record(keywordData.keyword_info);
    const keywordProperties = record(keywordData.keyword_properties);
    return {
      keyword: string(keywordData.keyword),
      rank: 0,
      searchVolume: number(keywordInfo.search_volume),
      url: "",
      intent: string(record(keywordData.search_intent_info).main_intent) || string(keywordProperties.main_intent),
      difficulty: number(keywordProperties.keyword_difficulty) || number(keywordData.keyword_difficulty),
      cpc: number(keywordInfo.cpc),
      opportunity: "competitor_gap" as const,
    };
  }).filter((keyword) => keyword.keyword);
}

function keywordIdentity(value: string) {
  return value
    .normalize("NFKC")
    .toLocaleLowerCase()
    .replace(/\bmonths\b/g, "month")
    .replace(/\boutfits\b/g, "outfit")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function looksLikeAddressKeyword(value: string) {
  const normalized = keywordIdentity(value);
  return /\b\d{5}(?:\s+\d{4})?\b/.test(normalized)
    && /\b(?:avenue|ave|boulevard|blvd|drive|dr|lane|ln|road|rd|street|st|way)\b/.test(normalized);
}

export function mergeKeywordStrategy(groups: StrategyKeyword[][], limit = 24) {
  const queues = groups.map((group) => [...group]);
  const seen = new Set<string>();
  const strategy: StrategyKeyword[] = [];
  while (strategy.length < limit && queues.some((queue) => queue.length)) {
    for (const queue of queues) {
      const candidate = queue.shift();
      if (!candidate) continue;
      const key = keywordIdentity(candidate.keyword);
      if (!key || looksLikeAddressKeyword(candidate.keyword) || seen.has(key)) continue;
      seen.add(key);
      strategy.push(candidate);
      if (strategy.length === limit) break;
    }
  }
  return strategy;
}

const CONTEXT_STOP_WORDS = new Set([
  "about", "across", "after", "also", "and", "are", "been", "business", "customer", "for", "from", "help", "into", "more", "people", "provide", "service", "services", "that", "the", "their", "them", "they", "this", "through", "want", "we", "who", "with", "you", "your",
]);

const SERVICE_SEED_TERMS = /^(?:agency|coach|coaching|consultant|consulting|counseling|counselor|realtor)$/i;

export function buildBuyerSeedKeywords(context: BusinessContext | undefined, limit = 4): string[] {
  const seen = new Set<string>();
  const seeds: string[] = [];
  const add = (value: string) => {
    const keyword = keywordIdentity(value);
    if (!keyword || keyword.split(/\s+/).length < 2 || seen.has(keyword) || seeds.length >= limit) return;
    seen.add(keyword);
    seeds.push(keyword);
  };
  const description = [context?.productsServices, context?.problemSolved, context?.audienceChallengesGoals]
    .filter(Boolean).join(" ");
  const collegeAdmissionsContext = /\bcollege\b/i.test(description) && /\badmissions?\b/i.test(description);
  if (collegeAdmissionsContext && /\bcounsel/i.test(description)) {
    add("college counseling");
    add("college counselor");
    add("college admissions counseling");
    add("college admissions counselor");
  }
  const segments = [context?.productsServices]
    .filter((value): value is string => Boolean(value?.trim()))
    .flatMap((value) => value.split(/\s*(?:[,;\n.]|\band\b)\s*/i));
  for (const segment of segments) {
    const tokens = keywordIdentity(segment).split(/\s+/)
      .filter((token) => token.length >= 3 && !CONTEXT_STOP_WORDS.has(token));
    const anchor = tokens.findIndex((token) => SERVICE_SEED_TERMS.test(token));
    if (anchor >= 0) {
      const seed = tokens.slice(Math.max(0, anchor - 2), anchor + 1).join(" ");
      add(seed);
      if (/\bcounseling$/i.test(seed)) add(seed.replace(/counseling$/i, "counselor"));
      else if (/\bconsulting$/i.test(seed)) add(seed.replace(/consulting$/i, "consultant"));
      else if (/\bcoaching$/i.test(seed)) add(seed.replace(/coaching$/i, "coach"));
    } else if (tokens.length >= 2 && tokens.length <= 4) {
      add(tokens.join(" "));
    }
  }
  if (collegeAdmissionsContext && /\bcounsel/i.test(description)) {
    add("college admissions counselor");
  }
  return seeds.slice(0, Math.max(0, limit));
}

export function buildContextSeedKeywords(context: BusinessContext | undefined, limit = 12): StrategyKeyword[] {
  const seen = new Set<string>();
  const candidates: StrategyKeyword[] = [];
  const segments = [context?.productsServices, context?.problemSolved, context?.idealCustomer, context?.audienceChallengesGoals, context?.differentiation]
    .filter((value): value is string => Boolean(value?.trim()))
    .flatMap((value) => value.split(/\s*(?:[,;\n.]|\band\b)\s*/i));
  for (const segment of segments) {
    const tokens = keywordIdentity(segment).split(/\s+/)
      .filter((token) => token.length >= 3 && !CONTEXT_STOP_WORDS.has(token));
    if (tokens.length < 2 || tokens.length > 5) continue;
    const keyword = tokens.join(" ");
    const key = keywordIdentity(keyword);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    candidates.push({
      keyword,
      rank: 0,
      searchVolume: 0,
      url: "",
      intent: "commercial",
      difficulty: 0,
      cpc: 0,
      opportunity: "site_idea",
    });
    if (candidates.length === limit) break;
  }
  return candidates;
}

const COMMON_NON_COMPETITOR_DOMAINS = /(?:facebook|instagram|linkedin|reddit|wikipedia|youtube)\.com$/i;

function domainFromSerpItem(item: unknown, competitorName: string, targetDomain: string) {
  const row = record(item);
  if (string(row.type) && string(row.type) !== "organic") return "";
  const url = string(row.url);
  if (!url) return "";
  try {
    const domain = normalizeWebsite(url).domain;
    if (domain === targetDomain || COMMON_NON_COMPETITOR_DOMAINS.test(domain)) return "";
    const nameTokens = keywordIdentity(competitorName).split(/\s+/).filter((token) => token.length >= 4);
    const evidence = keywordIdentity(`${domain} ${string(row.title)}`);
    return nameTokens.some((token) => evidence.includes(token)) ? domain : "";
  } catch {
    return "";
  }
}

async function resolveNamedCompetitorDomains(
  competitors: Array<{ name: string; url?: string | null }>,
  targetDomain: string,
  location: string,
  login: string,
  password: string,
) {
  const unresolved = competitors.filter((competitor) => competitor.name.trim() && !competitor.url);
  const results = await Promise.allSettled(unresolved.map((competitor) => dataForSeoPost(
    "/v3/serp/google/organic/live/advanced",
    [{ keyword: competitor.name.trim(), location_name: location, language_code: "en", depth: 10 }],
    login,
    password,
  )));
  return results.flatMap((result, index) => {
    if (result.status !== "fulfilled") return [];
    const items = array(firstResult(result.value).items);
    const domain = items.map((item) => domainFromSerpItem(item, unresolved[index].name, targetDomain)).find(Boolean);
    return domain ? [domain] : [];
  });
}

export async function runDataForSeoAudit(
  websiteValue: string,
  locationName: string,
  login: string,
  password: string,
  businessContext?: BusinessContext,
  knownCompetitors: Array<{ name: string; url?: string | null }> = [],
  onProgress: (progress: number) => Promise<void> | void = () => undefined,
  strategyModel: BusinessSearchBriefConfig = {},
): Promise<SeoAuditResult> {
  const website = normalizeWebsite(websiteValue);
  const location = locationName.trim() || "United States";
  const businessSearchBrief = await createBusinessSearchBrief(businessContext ?? {}, knownCompetitors, strategyModel);
  const categorySeeds = themeSeeds(businessSearchBrief, 16);
  const contextSeeds = categorySeeds.map((keyword) => ({
    keyword,
    rank: 0,
    searchVolume: 0,
    url: "",
    intent: "commercial",
    difficulty: 0,
    cpc: 0,
    opportunity: "site_idea" as const,
  }));
  const buyerSeedThemes = businessSearchBrief.themes.filter((theme) => theme.funnelRole === "conversion" || theme.funnelRole === "consideration");
  const buyerSeeds = themeSeeds({ ...businessSearchBrief, themes: buyerSeedThemes.length ? buyerSeedThemes : businessSearchBrief.themes }, 8);
  // LLM target metrics can be the slowest live endpoint. Start it alongside
  // the baseline audit and contain failure so it never blocks core SEO results.
  const llmPromise = dataForSeoPost("/v3/ai_optimization/llm_mentions/target_metrics/live", [{
    target: [{ domain: website.domain, search_filter: "include" }],
    location_code: 2840,
    language_code: "en",
    internal_list_limit: 10,
  }], login, password, 30_000)
    .then((value) => ({ status: "fulfilled" as const, value }))
    .catch((reason: unknown) => ({ status: "rejected" as const, reason }));
  const [pagePayload, rankingsPayload, competitorsPayload, ideasPayload, categoryIdeasPayload, buyerSuggestionResults, historyPayload, homepageContent] = await Promise.all([
    dataForSeoPost("/v3/on_page/instant_pages", [{ url: website.url, enable_javascript: true }], login, password),
    dataForSeoPost("/v3/dataforseo_labs/google/ranked_keywords/live", [{
      target: website.domain, location_name: location, language_name: "English",
      item_types: ["organic", "local_pack", "featured_snippet"], limit: 100,
    }], login, password),
    dataForSeoPost("/v3/dataforseo_labs/google/competitors_domain/live", [{
      target: website.domain, location_name: location, language_name: "English",
      item_types: ["organic", "local_pack"], exclude_top_domains: true, limit: 5,
    }], login, password),
    dataForSeoPost("/v3/dataforseo_labs/google/keywords_for_site/live", [{
      target: website.domain,
      location_name: location,
      language_name: "English",
      filters: ["keyword_info.search_volume", ">", 0],
      order_by: ["relevance,desc", "keyword_info.search_volume,desc"],
      limit: 100,
    }], login, password),
    categorySeeds.length ? dataForSeoPost("/v3/dataforseo_labs/google/keyword_ideas/live", [{
      keywords: categorySeeds,
      location_name: location,
      language_name: "English",
      filters: ["keyword_info.search_volume", ">", 0],
      order_by: ["keyword_info.search_volume,desc"],
      limit: 150,
    }], login, password) : Promise.resolve({ status_code: 20000, tasks: [{ status_code: 20000, result: [{ items: [] }] }] }),
    Promise.allSettled(buyerSeeds.map((keyword) => dataForSeoPost("/v3/dataforseo_labs/google/keyword_suggestions/live", [{
      keyword,
      location_name: location,
      language_name: "English",
      include_seed_keyword: true,
      ignore_synonyms: false,
      filters: ["keyword_info.search_volume", ">", 0],
      order_by: ["keyword_info.search_volume,desc", "keyword_info.cpc,desc"],
      limit: 100,
    }], login, password, 20_000))),
    dataForSeoPost("/v3/dataforseo_labs/google/historical_rank_overview/live", [{
      target: website.domain,
      location_name: location,
      language_name: "English",
      correlate: true,
    }], login, password),
    dataForSeoPost("/v3/on_page/content_parsing/live", [{ url: website.url, markdown_view: true }], login, password),
  ]);
  await onProgress(30);

  const pageResult = firstResult(pagePayload);
  const page = record(array(pageResult.items)[0]);
  const rankings = firstResult(rankingsPayload);
  const organicMetrics = record(record(rankings.metrics).organic);
  const competitorResult = firstResult(competitorsPayload);
  const competitors = array(competitorResult.items).slice(0, 5).map((item) => {
    const competitor = record(item);
    return { domain: string(competitor.domain), sharedKeywords: number(competitor.intersections) };
  }).filter((competitor) => competitor.domain && competitor.domain.toLowerCase().replace(/^www\./, "") !== website.domain);
  const rankedKeywords = parseRankedKeywords(rankings);
  const keywordIdeas = parseKeywordIdeas(firstResult(ideasPayload));
  const categoryKeywordIdeas = parseKeywordIdeas(firstResult(categoryIdeasPayload));
  const buyerKeywordIdeas = buyerSuggestionResults.flatMap((result) => result.status === "fulfilled"
    ? parseKeywordIdeas(firstResult(result.value))
    : []);
  const historicalPerformance = parseHistoricalRankOverview(historyPayload);

  const homepageResult = firstResult(homepageContent);
  const homepageItem = record(array(homepageResult.items)[0]);
  const parsedHomepage = parseContentPage(homepageItem, "homepage");
  parsedHomepage.url = website.url;
  const selectedPages = selectImportantPageLinks(website.url, parsedHomepage.links ?? [], 8);
  const remainingPageResults = await Promise.allSettled(selectedPages.slice(1).map(async (selected) => {
    const payload = await dataForSeoPost("/v3/on_page/content_parsing/live", [{ url: selected.url, markdown_view: true }], login, password);
    const result = firstResult(payload);
    const item = record(array(result.items)[0]);
    const pageEvidence = parseContentPage(item, selected.role);
    pageEvidence.url = selected.url;
    return pageEvidence;
  }));
  const pages = [parsedHomepage, ...remainingPageResults.flatMap((result) => result.status === "fulfilled" ? [result.value] : [])]
    .filter((page) => page.text.trim())
    .slice(0, 5);
  const businessEvidence = [businessContext?.productsServices, businessContext?.problemSolved, businessContext?.idealCustomer, businessContext?.audienceChallengesGoals, businessContext?.differentiation, businessContext?.market]
    .filter((value): value is string => Boolean(value?.trim())).join(". ");
  const siteVocabulary = extractSiteVocabulary(pages, businessEvidence);
  await onProgress(45);

  const checks = record(page.checks);
  const issues: SeoAuditResult["issues"] = Object.entries(checks)
    .filter(([code, active]) => active === true && code in CHECK_LABELS)
    .map(([code]) => ({
      code,
      label: CHECK_LABELS[code] ?? code.replaceAll("_", " "),
      severity: CRITICAL_CHECKS.has(code) ? "critical" : "warning",
    }));
  if (page.broken_links === true && !issues.some((issue) => issue.code === "broken_links")) {
    issues.unshift({ code: "broken_links", label: "Page contains broken links", severity: "critical" });
  }

  const providedDomains = knownCompetitors.flatMap((competitor) => {
    if (!competitor.url) return [];
    try { return [normalizeWebsite(competitor.url).domain]; } catch { return []; }
  });
  const resolvedNamedDomains = await resolveNamedCompetitorDomains(knownCompetitors, website.domain, location, login, password);
  const directCompetitorDomains = new Set([...providedDomains, ...resolvedNamedDomains]);
  const competitorDomains = [...new Set([...providedDomains, ...resolvedNamedDomains, ...competitors.map((competitor) => competitor.domain)])]
    .filter((domain) => domain && domain !== website.domain)
    .slice(0, 5);
  if (competitorDomains.length < 2) {
    throw new Error("Destiny needs at least two resolvable competitor domains. Add competitor website URLs and retry.");
  }

  const gapResults = await Promise.allSettled(competitorDomains.map((domain) => dataForSeoPost(
    "/v3/dataforseo_labs/google/domain_intersection/live",
    [{
      target1: domain,
      target2: website.domain,
      location_name: location,
      language_name: "English",
      intersections: false,
      item_types: ["organic", "local_pack"],
      filters: ["keyword_data.keyword_info.search_volume", ">", 0],
      order_by: ["keyword_data.keyword_info.search_volume,desc"],
      limit: 300,
    }],
    login,
    password,
  )));
  const gapEvidence = gapResults.flatMap((result, index) => result.status === "fulfilled"
    ? [{ domain: competitorDomains[index], payload: result.value }]
    : []);
  if (gapEvidence.length < 2) {
    throw new Error("Destiny could not retrieve enough live competitor evidence. Retry the audit in a moment.");
  }
  await onProgress(65);
  const gapGroups = gapEvidence.map((evidence) => ({
    ...evidence,
    keywords: parseGapKeywords(firstResult(evidence.payload)),
  }));
  const competitorRankCounts = new Map<string, number>();
  const directCompetitorRankCounts = new Map<string, number>();
  const gapByKeyword = new Map<string, StrategyKeyword>();
  for (const group of gapGroups) {
    const seenInCompetitor = new Set<string>();
    for (const keyword of group.keywords) {
      const key = keywordIdentity(keyword.keyword);
      if (!key || seenInCompetitor.has(key)) continue;
      seenInCompetitor.add(key);
      competitorRankCounts.set(key, (competitorRankCounts.get(key) ?? 0) + 1);
      if (directCompetitorDomains.has(group.domain)) {
        directCompetitorRankCounts.set(key, (directCompetitorRankCounts.get(key) ?? 0) + 1);
      }
      const existing = gapByKeyword.get(key);
      if (!existing || keyword.searchVolume > existing.searchVolume) gapByKeyword.set(key, keyword);
    }
  }
  const gapKeywords = [...gapByKeyword.values()].sort((a, b) =>
    (competitorRankCounts.get(keywordIdentity(b.keyword)) ?? 0) - (competitorRankCounts.get(keywordIdentity(a.keyword)) ?? 0)
      || b.searchVolume - a.searchVolume
      || a.keyword.localeCompare(b.keyword));
  const strategyCandidates = mergeKeywordStrategy([rankedKeywords, gapKeywords, buyerKeywordIdeas, keywordIdeas, categoryKeywordIdeas, contextSeeds], 500)
    .map((keyword) => ({
      ...keyword,
      competitorRankers: competitorRankCounts.get(keywordIdentity(keyword.keyword)) ?? 0,
      directCompetitorRankers: directCompetitorRankCounts.get(keywordIdentity(keyword.keyword)) ?? 0,
    }));
  const intentResult = strategyCandidates.length ? await dataForSeoPost("/v3/dataforseo_labs/google/search_intent/live", [{
    keywords: strategyCandidates.slice(0, 500).map((keyword) => keyword.keyword),
    language_name: "English",
  }], login, password, 20_000).then(firstResult).catch(() => null) : null;
  const intentByKeyword = new Map(array(intentResult?.items).flatMap((item) => {
    const row = record(item);
    const label = string(record(row.keyword_intent).label);
    const key = keywordIdentity(string(row.keyword));
    return key && label ? [[key, label] as const] : [];
  }));
  const intentEnrichedCandidates = strategyCandidates.map((keyword) => ({
    ...keyword,
    intent: intentByKeyword.get(keywordIdentity(keyword.keyword)) || keyword.intent,
  }));
  const rankedKeywordsForStrategy = rankKeywordOpportunities(intentEnrichedCandidates, businessContext ?? {}, 300, businessSearchBrief);
  const keywords = selectDiversifiedKeywordOpportunities(rankedKeywordsForStrategy, 50).map((keyword) => ({
    ...keyword,
    normalizedKeyword: keywordIdentity(keyword.keyword),
    matchedTerms: [],
    reason: keyword.priorityReason,
    essential: keyword.relevanceTier === "core" && Number(keyword.revenueFit ?? 0) >= 0.65
      && ((keyword.opportunity === "competitor_gap" && Number(keyword.directCompetitorRankers ?? 0) >= 1)
        || keyword.providerIntent === "transactional"),
  }));
  await onProgress(80);

  const firstAcceptedKeyword = keywords.find((keyword) => keyword.essential) ?? keywords[0];
  const distributionTopic = firstAcceptedKeyword?.keyword ?? siteVocabulary.find((term) => term.term.includes(" "))?.term ?? website.domain;
  const [redditResult, quoraResult, publisherResult] = await Promise.allSettled([
    dataForSeoPost("/v3/serp/google/organic/live/advanced", [{ keyword: `reddit ${distributionTopic}`, location_name: location, language_code: "en", depth: 10 }], login, password),
    dataForSeoPost("/v3/serp/google/organic/live/advanced", [{ keyword: `quora ${distributionTopic}`, location_name: location, language_code: "en", depth: 10 }], login, password),
    dataForSeoPost("/v3/serp/google/organic/live/advanced", [{ keyword: distributionTopic, location_name: location, language_code: "en", depth: 20 }], login, password),
  ]);
  const llmResult = await llmPromise;
  const distributionOpportunities = [redditResult, quoraResult].flatMap((result) => result.status === "fulfilled"
    ? parseDistributionSerp(result.value, distributionTopic)
    : []).filter((item, index, all) => all.findIndex((candidate) => candidate.url === item.url) === index).slice(0, 8);
  const publisherOpportunities = publisherResult.status === "fulfilled"
    ? parsePublisherSerp(publisherResult.value, distributionTopic, [website.domain, ...competitorDomains])
    : [];
  const llmVisibility = llmResult.status === "fulfilled"
    ? parseLlmVisibility(llmResult.value, llmResult.value)
    : { status: "unavailable" as const, totalMentions: 0, aiSearchVolume: 0, platforms: [], topCitedDomains: [], reason: "DataForSEO LLM visibility did not finish within this audit window." };
  await onProgress(90);

  const analyzedCompetitors = competitorDomains.map((domain) => ({
    domain,
    sharedKeywords: competitors.find((competitor) => competitor.domain === domain)?.sharedKeywords ?? 0,
  }));
  const acceptedGapCount = keywords.filter((keyword) => keyword.opportunity === "competitor_gap").length;

  return {
    source: "dataforseo",
    sourceLabel: "Live DataForSEO audit",
    domain: website.domain,
    fetchedAt: new Date().toISOString(),
    metrics: {
      criticalIssues: issues.filter((issue) => issue.severity === "critical").length,
      warnings: issues.filter((issue) => issue.severity === "warning").length,
      rankingKeywords: number(organicMetrics.count) || number(rankings.total_count),
      newKeywords: number(organicMetrics.is_new),
      lostKeywords: number(organicMetrics.is_lost),
      estimatedOrganicTraffic: number(organicMetrics.etv),
      contentGaps: acceptedGapCount,
      reviewCount: 0,
      onPageScore: typeof page.onpage_score === "number" ? page.onpage_score : null,
    },
    historicalPerformance,
    issues,
    competitors: analyzedCompetitors,
    keywords,
    pages,
    siteVocabulary,
    distributionOpportunities,
    publisherOpportunities,
    llmVisibility,
    businessSearchBrief,
    notices: [
      "Keyword and competitor indexes are DataForSEO estimates updated on their provider schedule.",
      `Destiny inspected ${pages.length} verified strategic page${pages.length === 1 ? "" : "s"}; blog posts and fabricated fallback URLs do not shape business relevance.`,
      `The approval pool is prioritized by core business relevance, revenue intent, monthly demand, ranking difficulty, commercial value, and opportunity evidence across ${competitorDomains.length} competitor domains.`,
      directCompetitorDomains.size
        ? `${directCompetitorDomains.size} business competitor${directCompetitorDomains.size === 1 ? " is" : "s are"} weighted more strongly than discovered publishers and other search-landscape domains.`
        : "Discovered domains are treated as search-landscape evidence until the user identifies direct business competitors.",
      `${businessSearchBrief.source === "claude-opus-4-8" ? "Claude Opus 4.8" : "Destiny's deterministic fallback"} synthesized every onboarding answer into ${businessSearchBrief.themes.length} evidence-backed search themes before keyword expansion.`,
      businessSearchBrief.warning ?? "The semantic brief separates what the company sells from what its product enables customers to build.",
      buyerSeeds.length ? `Long-tail buyer opportunities were expanded from ${buyerSeeds.length} theme-balanced seed${buyerSeeds.length === 1 ? "" : "s"} and reclassified with DataForSEO Search Intent.` : "No evidence-backed buyer seed could be derived from onboarding.",
      contextSeeds.length ? "Site and category ideas are seeded across distinct onboarding themes; measured DataForSEO volume and intent remain authoritative." : "No usable category seed could be derived from the complete onboarding record.",
      distributionOpportunities.length ? "Distribution links point to individual live Reddit or Quora threads." : "No individual Reddit or Quora thread passed Destiny's live-link check in this audit.",
      "Google review count stays at zero until Google Business Profile is connected.",
    ],
  };
}

export async function runSeoAudit(input: {
  website: string;
  locationName?: string;
  login?: string;
  password?: string;
  businessContext?: BusinessContext;
  knownCompetitors?: Array<{ name: string; url?: string | null }>;
  onProgress?: (progress: number) => Promise<void> | void;
  strategyModel?: BusinessSearchBriefConfig;
}) {
  if (input.login && input.password) {
    return runDataForSeoAudit(input.website, input.locationName || "United States", input.login, input.password, input.businessContext, input.knownCompetitors, input.onProgress, input.strategyModel);
  }
  await input.onProgress?.(90);
  return runDemoAudit(input.website, input.businessContext);
}
